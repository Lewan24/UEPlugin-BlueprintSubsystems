// Copyright Epic Games, Inc. All Rights Reserved.

#include "BlueprintSubsystemsBPLibrary.h"
#include "BlueprintSubsystems.h"

UBlueprintSubsystemsBPLibrary::UBlueprintSubsystemsBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

// float UBlueprintSubsystemsBPLibrary::BlueprintSubsystemsSampleFunction(float Param)
// {
// 	return -1;
// }

